﻿using ToyRobot.Helpers;

namespace ToyRobot
{
    public class Robot : IRobot
    {
        public int East = 0;
        public int North = 0;
        public Directions Direction;
        public string CurrentPosition() => East + "," + North + "," + Direction.ToString();

        public void MoveForward()
        {
            switch (Direction)
            {
                case Directions.East:
                    East += 1;
                    break;
                case Directions.West:
                    East -= 1;
                    break;
                case Directions.North:
                    North += 1;
                    break;
                case Directions.South:
                    North -= 1;
                    break;
            }
        }

        public void TurnLeft()
        {
            switch (Direction)
            {
                case Directions.East:
                    Direction = Directions.North;
                    break;
                case Directions.West:
                    Direction = Directions.South;
                    break;
                case Directions.North:
                    Direction = Directions.West;
                    break;
                case Directions.South:
                    Direction = Directions.East;
                    break;
            }
        }

        public void TurnRight()
        {
            switch (Direction)
            {
                case Directions.East:
                    Direction = Directions.South;
                    break;
                case Directions.West:
                    Direction = Directions.North;
                    break;
                case Directions.North:
                    Direction = Directions.East;
                    break;
                case Directions.South:
                    Direction = Directions.West;
                    break;
            }
        }
    }
}
