﻿using Microsoft.Extensions.Configuration;
using ToyRobot;
using ToyRobot.Helpers;
using Action = ToyRobot.Action;

//app settings data retieval
ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
IConfiguration c = configurationBuilder.AddJsonFile("appsettings.json").AddEnvironmentVariables().Build();
var settings = c.GetRequiredSection("Settings").Get<Settings>();

//var collection = new ServiceCollection();
//collection.AddScoped<IRobot, Robot>();

Action action = new Action(settings, new Robot());
CommandHandler CommandHandler = new CommandHandler(action, settings);

if (File.Exists(AppDomain.CurrentDomain.BaseDirectory+settings.InputFile))
{
    string[] commands = File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + settings.InputFile);
    Console.WriteLine(CommandHandler.Start(commands));
}
else
{
    Console.WriteLine("Not a .txt file. Please try again.");
    Console.Write(@"The correct command formats are as follows:
PLACE X,Y,DIRECTION
MOVE
RIGHT
LEFT
REPORT
-------------
Please review your input file and try again.");
}