﻿namespace ToyRobot.Helpers
{
    public class Constants
    {
        public const string Move = "move";
        public const string Right = "right";
        public const string Left = "left";

        public const string Place = "place";
        public const string Report = "report";

    }
}
