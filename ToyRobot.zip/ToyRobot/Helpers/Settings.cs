﻿namespace ToyRobot.Helpers
{
    public class Settings
    {
        public int Width { get; set; }
        public int Length { get; set; }
        public string SuccessMessage { get; set; }
        public string ErrorMessage { get; set; }
        public string InputFile { get; set; }
    }
}
