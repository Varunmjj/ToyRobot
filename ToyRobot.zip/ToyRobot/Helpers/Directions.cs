﻿namespace ToyRobot.Helpers
{
    public enum Directions
    {
        East,
        West,
        North,
        South
    }
}
