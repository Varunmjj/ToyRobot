﻿using ToyRobot.Helpers;

namespace ToyRobot
{
    public class Action
    {
        private Settings _settings;
        private Robot _robot;

        //passing depenedency through constructor
        public Action(Settings settings, Robot robot)
        {
            _settings = settings;
            _robot = robot;
        }

        /// <summary>
        /// placing the initial postiton for robot
        /// </summary>
        /// <param name="east"></param>
        /// <param name="north"></param>
        /// <param name="direction"></param>
        public string Place(int east, int north, Directions direction)
        {
            //robot to not go out of scope, less than 0 and greater than playground size cofigured
            if (east <_settings.Width && east >=0 && north <_settings.Length && north >=0)
            {
                _robot = new Robot
                {
                    Direction = direction,
                    East = east,
                    North = north
                };
                return _settings.SuccessMessage;
            }
            return _settings.ErrorMessage;
        }


        /// <summary>
        /// return the current position of robot
        /// </summary>
        /// <returns></returns>
        public string CurrentPosition() => _robot.CurrentPosition();

        /// <summary>
        /// Does Movement of robot forward or rotate in current positions left/right
        /// </summary>
        /// <param name="move"></param>
        public void Moves(string move, out bool isInputValid)
        {
            isInputValid = true;
            switch (move.ToLower())
            {
                case Constants.Move:
                    if (CanMoveForward())
                    {
                        _robot.MoveForward();
                    }
                    else
                    {
                        isInputValid = false;
                    }
                    break;
                case Constants.Right:
                    _robot.TurnRight();
                    break;
                case Constants.Left:
                    _robot.TurnLeft();
                    break;
            }
        }

        private bool CanMoveForward()
        {
            return _robot.Direction switch
            {
                Directions.East => (_robot.East + 1 < _settings.Width) ? true : false,
                Directions.West => (_robot.East - 1 >= 0) ? true : false,
                Directions.North => (_robot.North + 1 < _settings.Length) ? true : false,
                Directions.South => (_robot.North - 1 >= 0) ? true : false,
                _ => false
            };
        }
    }
}
