﻿namespace ToyRobot
{
    interface IRobot
    {
        void MoveForward();
        void TurnLeft();
        void TurnRight();
        string CurrentPosition();
    }
}
