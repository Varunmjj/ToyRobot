﻿using ToyRobot.Helpers;

namespace ToyRobot
{
    public class CommandHandler
    {
        private Action _action;
        private Settings _settings;
        private bool _placed = false;
        public CommandHandler(Action action, Settings settings)
        {
            _action = action;
            _settings = settings;
        }

        public string Start(string[] commands)
        {
            string response = string.Empty;
            foreach (string command in commands)
            {
                if (_placed)
                {
                    response = ProcessCommand(command);
                }
                else if (command.ToLower().StartsWith(Constants.Place))
                {
                    _placed = true;
                    response = ProcessCommand(command);
                }                 
            }
            return response;
        }

        public string ProcessCommand(string command)
        {
            string response = _settings.ErrorMessage;
            switch (command.ToLower())
            {
                case string a when a.StartsWith(Constants.Place):
                    string[] coordinates = command.Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    if (coordinates.Length == 4)
                    {
                        if (Int32.TryParse(coordinates[1], out int east) && Int32.TryParse(coordinates[2], out int north) &&
                            Enum.TryParse(coordinates[3], true, out Directions direction))
                        {
                            response = _action.Place(east, north, direction);
                        }
                    }
                    break;
                case Constants.Left or Constants.Right or Constants.Move:
                    _action.Moves(command, out bool isInputValid);
                    if (isInputValid)
                    {
                        response = _settings.SuccessMessage;
                    }
                    break;
                case Constants.Report:
                    response = _action.CurrentPosition();
                    break;
            }
            return response;
        }
    }
}
