﻿using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ToyRobot.Helpers;

namespace ToyRobot
{
    [TestClass]
    public class CommandHandlerTest
    {
        Action Action;
        Settings Settings;
        public CommandHandlerTest()
        {
            ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
            IConfiguration c = configurationBuilder.AddJsonFile("appsettings.json").AddEnvironmentVariables().Build();
            Settings = c.GetRequiredSection("Settings").Get<Settings>();
            Action = new Action(Settings, new Robot());

        }

        [TestMethod]
        public void ProcessPlaceCommand()
        {
            CommandHandler commandHandler = new CommandHandler(Action, Settings);
            string[] input = { "PLACE 4,3,WEST" };
            var res = commandHandler.Start(input);
            Assert.IsNotNull(res);
            Assert.AreEqual(Settings.SuccessMessage, res);
        }

        [TestMethod]
        public void ProcessPlaceInvalidCommand()
        {
            CommandHandler commandHandler = new CommandHandler(Action, Settings);
            string[] input = { "PLACE 5,3,WEST" };
            var res = commandHandler.Start(input);
            Assert.IsNotNull(res);
            Assert.AreEqual(Settings.ErrorMessage, res);
        }

        [TestMethod]
        public void ProcessMoveCommand()
        {
            CommandHandler commandHandler = new CommandHandler(Action, Settings);
            string[] input = { "PLACE 4,3,WEST", "Move" };
            var res = commandHandler.Start(input);
            Assert.IsNotNull(res);
            Assert.AreEqual(Settings.SuccessMessage, res);
        }

        [TestMethod]
        public void ProcessRightCommand()
        {
            CommandHandler commandHandler = new CommandHandler(Action, Settings);
            string[] input = { "PLACE 4,3,WEST", "Right" };
            var res = commandHandler.Start(input);
            Assert.IsNotNull(res);
            Assert.AreEqual(Settings.SuccessMessage, res);
        }

        [TestMethod]
        public void ProcessLeftCommand()
        {
            CommandHandler commandHandler = new CommandHandler(Action, Settings);
            string[] input = { "PLACE 4,3,WEST", "Left" };
            var res = commandHandler.Start(input);
            Assert.IsNotNull(res);
            Assert.AreEqual(Settings.SuccessMessage, res);
        }

        [TestMethod]
        public void ProcessReportCommand()
        {
            CommandHandler commandHandler = new CommandHandler(Action, Settings);
            string[] input = { "PLACE 4,3,WEST", "Report" };
            var res = commandHandler.Start(input);
            Assert.IsNotNull(res);
            Assert.AreEqual("4,3,West", res);
        }

        [TestMethod]
        public void ProcessLeftEASTCommand()
        {
            CommandHandler commandHandler = new CommandHandler(Action, Settings);
            string[] input = { "PLACE 4,3,EAST", "Left", "Report" };
            var res = commandHandler.Start(input);
            Assert.IsNotNull(res);
            Assert.AreEqual("4,3,North", res);
        }
    }
}
